package sisop;

/**
 * Implementacion de un planificador Multilevel Feedback Queue. 
 * Esta clase esta vacia.
 */ 
class MFQ extends Scheduler {

  public MFQ() {
    super("MFQ");
  }

  protected void scheduler_init() {
    throw new UnsupportedOperationException("Implementar este metodo");
  }


  public String scheduler_next() {
    throw new UnsupportedOperationException("Implementar este metodo");
  }

}
